# TheDom2Fast2Learnious
Learning about the DOM and how to manipulate it!
