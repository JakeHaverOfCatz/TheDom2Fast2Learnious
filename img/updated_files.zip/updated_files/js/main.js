let domsFavoriteWords = ["family", "family", "family", "family", "family", "family"]

function joinWords(arr){
    return arr.join(" ")
}

console.log(joinWords(domsFavoriteWords));

const headline = document.querySelector('.headline');
headline.className = 'headline';

const domQuote = document.createElement('h2');
domQuote.className = 'domQuote';
domQuote.innerHTML = '"I live my life a quarter mile at a time." -The Dom';
headline.append(domQuote);

domQuote.style.fontSize = '1.5rem';
domQuote.style.backgroundColor = 'black';
domQuote.style.display = "block";

headline.style.backgroundColor = 'black';
headline.style.fontSize = '2.5rem';
headline.style.width = '40%';

const clickedYes = document.createElement('h2');
clickedYes.className = 'clickedYes';
clickedYes.innerHTML = 'Winning\'s winning!';

const clickedNo = document.createElement('h2');
clickedNo.className = 'clickedNo';
clickedNo.innerHTML = 'That\'s not what I had in mind!';

const response = document.querySelector('.response');
response.className = 'response';

document.body.addEventListener('click', event => {
    if (event.target.matches('.yes')) {;
        response.append(clickedYes);
    } else if (event.target.matches('.no')) {
        response.append(clickedNo);
    }
})

// document.body.addEventListener('click', event => {
//     event.target.matches('.no');
//     response.append(clickedNo);
// })